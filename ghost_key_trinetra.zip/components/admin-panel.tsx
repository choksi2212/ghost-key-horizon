"use client"

// Admin panel for system management - probably need better auth than hardcoded password
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, Download, Trash2, Terminal, Server, UserX, Users, AlertTriangle } from "lucide-react"

// User interface for the user list
interface User {
  username: string
  hasKeystrokeModel: boolean
  hasVoiceModel: boolean
  lastActivity?: string
}

export function AdminPanel() {
  // Authentication state for admin access
  const [adminPassword, setAdminPassword] = useState("")
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false)
  const [loginError, setLoginError] = useState("")
  
  // User management state
  const [registeredUsers, setRegisteredUsers] = useState<string[]>([])
  const [targetUser, setTargetUser] = useState("")
  const [isDeletingUser, setIsDeletingUser] = useState(false)
  const [deletionResult, setDeletionResult] = useState<any>(null)

  // Fetch user list when admin is authenticated
  useEffect(() => {
    if (isAdminAuthenticated) {
      loadUserList()
    }
  }, [isAdminAuthenticated])

  // Simple admin authentication - TODO: implement proper auth system
  const authenticateAdmin = () => {
    if (adminPassword === "admin123") {
      setIsAdminAuthenticated(true)
      setLoginError("")
    } else {
      setLoginError("Invalid admin credentials")
    }
  }

  // Load the list of registered users from the API
  const loadUserList = async () => {
    try {
      const response = await fetch("/api/list-users")
      const data = await response.json()
      setRegisteredUsers(data.users || [])
    } catch (error) {
      console.error("Failed to fetch users:", error)
    }
  }

  // Permanently delete all user data - this is the nuclear option
  const permanentlyDeleteUser = async () => {
    if (!targetUser) {
      setLoginError("Please select a user to delete")
      return
    }

    // Extra confirmation dialog because this is destructive
    const confirmMessage = `⚠️ CRITICAL WARNING ⚠️

This will PERMANENTLY DELETE ALL DATA for user: ${targetUser}

This includes:
• All trained keystroke models
• All voice authentication models  
• All authentication logs and history
• All raw training data
• All user-specific files

This action CANNOT be undone!

Type the username "${targetUser}" to confirm:`

    const userConfirmation = prompt(confirmMessage)

    if (userConfirmation !== targetUser) {
      alert("❌ Deletion cancelled - username confirmation did not match")
      return
    }

    setIsDeletingUser(true)
    setDeletionResult(null)
    setLoginError("")

    try {
      const response = await fetch("/api/delete-user-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: targetUser,
          adminPassword: adminPassword,
        }),
      })

      const result = await response.json()
      setDeletionResult(result)

      if (result.success) {
        alert(`✅ Successfully deleted all data for user: ${targetUser}`)
        setTargetUser("")
        loadUserList() // Refresh the user list
      } else {
        setLoginError(result.message || "Failed to delete user data")
      }
    } catch (error) {
      setLoginError("Failed to delete user data: " + error)
    } finally {
      setIsDeletingUser(false)
    }
  }

  // Clear all security logs - another dangerous operation
  const purgeSecurityLogs = async () => {
    if (confirm("⚠️ WARNING: This will permanently delete all security logs. Continue?")) {
      try {
        await fetch("/api/clear-logs", { method: "POST" })
        alert("🧹 Security logs cleared successfully")
      } catch (error) {
        alert("❌ Failed to clear logs: " + error)
      }
    }
  }

  // Export all system data for backup purposes
  const exportSystemData = async () => {
    try {
      const response = await fetch("/api/export-all-data")
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const downloadLink = document.createElement("a")
      downloadLink.href = url
      downloadLink.download = `keystroke_auth_export_${new Date().toISOString().split("T")[0]}.zip`
      document.body.appendChild(downloadLink)
      downloadLink.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(downloadLink)
    } catch (error) {
      alert("❌ Failed to export data: " + error)
    }
  }

  // Show login screen if admin hasn't authenticated yet
  if (!isAdminAuthenticated) {
    return (
      <Card className="bg-slate-800/50 dark:bg-slate-900/50 border-slate-700/50 dark:border-slate-600/50 shadow-2xl backdrop-blur-sm">
        <CardHeader
          className="border-b border-slate-700/50 dark:border-slate-600/50"
          style={{
            background: "linear-gradient(to right, rgba(30, 41, 59, 0.8), rgba(51, 65, 85, 0.8))",
          }}
        >
          <CardTitle className="flex items-center gap-2 text-slate-100 dark:text-slate-200">
            <Shield className="w-5 h-5 text-purple-400" />
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Security Command Center
            </span>
          </CardTitle>
          <CardDescription className="text-slate-400 dark:text-slate-500">
            🔒 Administrative access required for system management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-6 bg-slate-800/30 dark:bg-slate-900/30">
          <div className="space-y-2">
            <Label htmlFor="admin-password" className="text-slate-300 dark:text-slate-400">
              Admin Credentials
            </Label>
            <Input
              id="admin-password"
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && authenticateAdmin()}
              placeholder="Enter admin password"
              className="bg-slate-700/50 dark:bg-slate-800/50 border-slate-600/50 dark:border-slate-700/50 text-slate-200 placeholder:text-slate-500 focus:border-purple-500/50 dark:focus:border-purple-400/50 transition-all duration-300"
            />
            <p className="text-xs text-slate-500">Default: admin123 (for demo purposes only)</p>
          </div>

          {loginError && (
            <Alert className="border-red-500/50 bg-red-500/10 text-red-300 dark:text-red-400">
              <AlertDescription>{loginError}</AlertDescription>
            </Alert>
          )}

          <Button
            onClick={authenticateAdmin}
            className="w-full bg-gradient-to-r from-purple-600/80 to-purple-700/80 hover:from-purple-500 hover:to-purple-600 border border-purple-500/50 text-white shadow-lg hover:shadow-xl transform hover:scale-[1.02] font-medium backdrop-blur-sm"
          >
            <Shield className="w-4 h-4 mr-2" />
            Authenticate Administrator
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* User Data Management */}
      <Card className="bg-slate-800/50 dark:bg-slate-900/50 border-slate-700/50 dark:border-slate-600/50 shadow-2xl backdrop-blur-sm">
        <CardHeader
          className="border-b border-slate-700/50 dark:border-slate-600/50"
          style={{
            background: "linear-gradient(to right, rgba(220, 38, 38, 0.8), rgba(239, 68, 68, 0.8))",
          }}
        >
          <CardTitle className="flex items-center gap-2 text-slate-100 dark:text-slate-200">
            <UserX className="w-5 h-5 text-red-400" />
            <span className="bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
              🗑️ User Data Management
            </span>
          </CardTitle>
          <CardDescription className="text-slate-400 dark:text-slate-500">
            ⚠️ DANGER ZONE: Permanently delete all user data including models, logs, and training data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-6 bg-slate-800/30 dark:bg-slate-900/30">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Select User to Delete</Label>
              <Select value={targetUser} onValueChange={setTargetUser}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600/50 text-slate-200">
                  <SelectValue placeholder="Choose user..." />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {registeredUsers.map((user) => (
                    <SelectItem key={user} value={user} className="text-slate-200 hover:bg-slate-700">
                      {user}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">Found {registeredUsers.length} registered users</p>
            </div>

            <div className="flex items-end">
              <Button
                onClick={permanentlyDeleteUser}
                disabled={!targetUser || isDeletingUser}
                className="w-full bg-gradient-to-r from-red-600/80 to-red-700/80 hover:from-red-500 hover:to-red-600 border border-red-500/50 text-white font-medium"
              >
                <UserX className="w-4 h-4 mr-2" />
                {isDeletingUser ? "Deleting..." : "🗑️ DELETE ALL USER DATA"}
              </Button>
            </div>
          </div>

          {deletionResult && (
            <Alert
              className={`border-${deletionResult.success ? "green" : "red"}-500/50 bg-${deletionResult.success ? "green" : "red"}-500/10`}
            >
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription className={`text-${deletionResult.success ? "green" : "red"}-300`}>
                <div className="font-medium">{deletionResult.message}</div>
                {deletionResult.deletionResults && (
                  <div className="mt-2 text-sm">
                    <div>
                      ✅ Keystroke Models: {deletionResult.deletionResults.keystrokeModels ? "Deleted" : "Not Found"}
                    </div>
                    <div>✅ Voice Models: {deletionResult.deletionResults.voiceModels ? "Deleted" : "Not Found"}</div>
                    <div>✅ Auth Logs: {deletionResult.deletionResults.authLogs ? "Cleaned" : "Not Found"}</div>
                    {deletionResult.deletionResults.errors.length > 0 && (
                      <div className="mt-1 text-red-400">Errors: {deletionResult.deletionResults.errors.join(", ")}</div>
                    )}
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-red-300">
                <div className="font-medium mb-1">⚠️ WARNING: This action is IRREVERSIBLE</div>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Deletes all trained ML models (keystroke & voice)</li>
                  <li>Removes all authentication logs and history</li>
                  <li>Erases all raw training data and samples</li>
                  <li>Clears user from audit dashboard</li>
                  <li>Cannot be undone - user will need to re-register</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Administration */}
      <Card className="bg-slate-800/50 dark:bg-slate-900/50 border-slate-700/50 dark:border-slate-600/50 shadow-2xl backdrop-blur-sm">
        <CardHeader
          className="border-b border-slate-700/50 dark:border-slate-600/50"
          style={{
            background: "linear-gradient(to right, rgba(30, 41, 59, 0.8), rgba(51, 65, 85, 0.8))",
          }}
        >
          <CardTitle className="flex items-center gap-2 text-slate-100 dark:text-slate-200">
            <Terminal className="w-5 h-5 text-purple-400" />
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              System Administration
            </span>
          </CardTitle>
          <CardDescription className="text-slate-400 dark:text-slate-500">
            ⚙️ Advanced system management and security controls
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-6 bg-slate-800/30 dark:bg-slate-900/30">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              onClick={exportSystemData}
              className="flex items-center gap-2 bg-blue-600/80 hover:bg-blue-500 border border-blue-500/50"
            >
              <Download className="w-4 h-4" />
              Export All Security Data
            </Button>

            <Button
              onClick={purgeSecurityLogs}
              variant="destructive"
              className="flex items-center gap-2 bg-red-600/80 hover:bg-red-500 border border-red-500/50"
            >
              <Trash2 className="w-4 h-4" />
              Purge Security Logs
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <Button
              className="flex items-center gap-2 bg-purple-600/80 hover:bg-purple-500 border border-purple-500/50"
              onClick={loadUserList}
            >
              <Users className="w-4 h-4" />
              Refresh User List ({registeredUsers.length})
            </Button>

            <Button
              className="flex items-center gap-2 bg-cyan-600/80 hover:bg-cyan-500 border border-cyan-500/50"
              onClick={() => alert("Feature coming soon")}
            >
              <Server className="w-4 h-4" />
              System Configuration
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <Card className="bg-slate-800/50 dark:bg-slate-900/50 border-slate-700/50 dark:border-slate-600/50 shadow-2xl backdrop-blur-sm">
        <CardHeader
          className="border-b border-slate-700/50 dark:border-slate-600/50"
          style={{
            background: "linear-gradient(to right, rgba(30, 41, 59, 0.8), rgba(51, 65, 85, 0.8))",
          }}
        >
          <CardTitle className="text-slate-100 dark:text-slate-200">System Status</CardTitle>
        </CardHeader>
        <CardContent className="p-6 bg-slate-800/30 dark:bg-slate-900/30">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-4 bg-slate-700/30 dark:bg-slate-800/30 rounded-lg border border-slate-600/30 dark:border-slate-700/30">
              <div className="text-2xl font-bold text-cyan-400">ACTIVE</div>
              <div className="text-sm text-slate-400">System Status</div>
            </div>
            <div className="p-4 bg-slate-700/30 dark:bg-slate-800/30 rounded-lg border border-slate-600/30 dark:border-slate-700/30">
              <div className="text-2xl font-bold text-cyan-400">{registeredUsers.length}</div>
              <div className="text-sm text-slate-400">Registered Users</div>
            </div>
            <div className="p-4 bg-slate-700/30 dark:bg-slate-800/30 rounded-lg border border-slate-600/30 dark:border-slate-700/30">
              <div className="text-2xl font-bold text-cyan-400">256MB</div>
              <div className="text-sm text-slate-400">Storage Used</div>
            </div>
            <div className="p-4 bg-slate-700/30 dark:bg-slate-800/30 rounded-lg border border-slate-600/30 dark:border-slate-700/30">
              <div className="text-2xl font-bold text-cyan-400">0.02s</div>
              <div className="text-sm text-slate-400">Avg Response</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
